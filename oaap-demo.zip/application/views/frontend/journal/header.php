<div>
    <div style="float:left;padding:20px; text-align:center; font-weight:bold; background-color:#45B000; color:#FFF; height:52px; border:1px dashed #FFF; font-size:16px; width:616px; line-height:50px;">
    	<?php echo $journal['name'];?>
    </div>
   </div>
<div style="clear:both;">&nbsp;</div>
