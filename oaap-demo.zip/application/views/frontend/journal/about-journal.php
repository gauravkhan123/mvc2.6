   		<!---banner--->
        <div class="banner">
           		 <div class="container">
                 	<div class="row">
                        &nbsp;
                    </div>
                </div>
        </div>

        
        <!----second2-row-body-contant-->
        <div class="second2-row">
        	<div class="container">
            	<div class="row">
                	<!----about us--- pages-->
                    <div class="col-lg-9 border-right">
                    	<div class="about_left">
                        	<h2>About this Journal</h2>
                            <?php echo $journal['about_journal'];?>
                        </div>
                    </div>
                    	<?php $this->load->view('frontend/includes/journal-right');?>
                </div>
            </div>
        </div>