       <?php $this->load->view('frontend/includes/slider');?>
        
                <!----second2-row-body-contant-->
        <div class="second2-row">
        	<div class="container">
            	<div class="row">
                	<!----about us--- pages-->
                    <div class="col-lg-9 border-right">
                    	<div class="about_left">
                            <div id="cse-search-results" style="padding-left:10px;"></div>
                            <div id="cse-search-results"></div>
                            <script type="text/javascript">
                              var googleSearchIframeName = "cse-search-results";
                              var googleSearchFormName = "cse-search-box";
                              var googleSearchFrameWidth = 800;
                              var googleSearchDomain = "www.google.com";
                              var googleSearchPath = "/cse";
                            </script>
                            <script type="text/javascript" src="http://www.google.com/afsonline/show_afs_search.js"></script>
                        </div>
                    </div>
                </div>
            </div>
        </div>