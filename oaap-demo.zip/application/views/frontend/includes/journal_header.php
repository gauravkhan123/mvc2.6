<table width="100%" border="0" cellspacing="0" cellpadding="0">

      <tr>

        <td id="contentPANE_CELLright" style="padding-left:0px;">

        <div id="BOX2_top-tail">

            <div id="BOX2_right-tail">

                <div id="BOX2_bot-tail">

                    <div id="BOX2_left-tail">

                        <div id="BOX2_top-left">

                            <div id="BOX2_top-right">

                                <div id="BOX2_bot-right">

                                    <div id="BOX2_bot-left">

                                        <div id="BOX2_indent">                                        

                                        <table width="96%" border="0" cellspacing="0" cellpadding="0" align="center">

  <tr>

    <td style="background:url(<?php echo base_url(); ?>assets/themes/frontend/images/journal-name-bg.gif); background-repeat:no-repeat; text-align:center; width:450px; height:64px; background-position:center; font-family:Verdana, Arial, Helvetica, sans-serif; font-size:14px; font-weight:bold; color:#FFFFFF;"><?php echo $data['journal']['name'];?></td>

    <td align="center"><a href="<?php echo site_url('journal/'.$data['journal']['Id']);?>"><img src="<?php echo base_url();?>media/journals/70/<?php echo $data['journal']['image'];?>" width="70" style="border:#CCCCCC 1px solid; padding:1px;" border="0" /></a></td>

  </tr>

</table>



                                        </div>

                                    </div>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

        <p id="clear"></p>

        </td>

      </tr>

    </table>