<div id="wrapper"><div id="announcement" style="padding:10px;"><table width="100%"><tr><td width="11%">
<strong>Announcement</strong> :</td>
<td width="89%"> <marquee><?php echo get_settings(6);?></marquee></td></tr></table></div></div>
