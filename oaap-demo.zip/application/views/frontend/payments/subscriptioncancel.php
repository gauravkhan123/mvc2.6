<div class="mid">
	<div class="web-wrap">
		 <?php $this->load->view('frontend/includes/slider');?>
	
		<div class="content">
			<div class="left-side" style="min-height:200px;">
                <h3>Subsciption order cancelled</h3>
				<p>Your order is cancelled successfully.</p>
            </div>
            </div>            
				<?php $this->load->view('frontend/includes/right');?>
		</div>
	</div>
</div>