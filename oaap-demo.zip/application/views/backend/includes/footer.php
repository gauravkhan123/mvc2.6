<footer>
                <p>&copy; <a href="<?php echo base_url();?>" target="_blank"><?php echo $this->config->item('site_name');?></a> <?php echo date('Y')?></p>
            </footer>