<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2014-12-27 10:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:24:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:24:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:24:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:24:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:24:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:24:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:24:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:25:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:25:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:25:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2014-12-27 10:25:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:26:51 --> Config Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:26:51 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:26:51 --> URI Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Router Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Output Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Security Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Input Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:26:51 --> Language Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Loader Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:26:51 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:26:51 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:26:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:26:51 --> Session Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:26:51 --> Session routines successfully run
DEBUG - 2014-12-27 10:26:51 --> Controller Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Model Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Model Class Initialized
DEBUG - 2014-12-27 10:26:51 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:26:51 --> DB Transaction Failure
ERROR - 2014-12-27 10:26:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:26:51 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:26:52 --> Config Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:26:52 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:26:52 --> URI Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Router Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Output Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Security Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Input Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:26:52 --> Language Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Loader Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:26:52 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:26:52 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:26:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:26:52 --> Session Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:26:52 --> Session routines successfully run
DEBUG - 2014-12-27 10:26:52 --> Controller Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Model Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Model Class Initialized
DEBUG - 2014-12-27 10:26:52 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:26:52 --> DB Transaction Failure
ERROR - 2014-12-27 10:26:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:26:52 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:13 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:13 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:13 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:13 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:13 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:13 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:13 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:13 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:13 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:13 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:13 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:13 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:13 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:14 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:14 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:14 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:14 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:14 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:14 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:14 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:14 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:14 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:14 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:14 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:14 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:14 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:14 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:14 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:14 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:14 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:14 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:14 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:14 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:14 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:14 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:14 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:14 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:14 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:14 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:14 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:21 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:21 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:21 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:21 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:21 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:21 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:21 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:21 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:21 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/includes/breadcrumb.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/includes/header.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/includes/footer.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/includes/left.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/products/category.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/themes/prabhabrass.php
DEBUG - 2014-12-27 10:28:21 --> Final output sent to browser
DEBUG - 2014-12-27 10:28:21 --> Total execution time: 0.3810
DEBUG - 2014-12-27 10:28:21 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:21 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:21 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:21 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:21 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:21 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:21 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:21 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:21 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:21 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/includes/breadcrumb.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/includes/header.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/includes/footer.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/prabhabrass/page-404.php
DEBUG - 2014-12-27 10:28:21 --> File loaded: application/views/themes/prabhabrass.php
DEBUG - 2014-12-27 10:28:21 --> Final output sent to browser
DEBUG - 2014-12-27 10:28:21 --> Total execution time: 0.1900
DEBUG - 2014-12-27 10:28:25 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:25 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:25 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:25 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:25 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:25 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:25 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:25 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:25 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:25 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/includes/breadcrumb.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/includes/header.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/includes/footer.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/includes/left.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/products/category.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/themes/prabhabrass.php
DEBUG - 2014-12-27 10:28:26 --> Final output sent to browser
DEBUG - 2014-12-27 10:28:26 --> Total execution time: 0.4070
DEBUG - 2014-12-27 10:28:26 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:26 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:26 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:26 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:26 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:26 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:26 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:26 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:26 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/includes/breadcrumb.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/includes/header.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/includes/footer.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/prabhabrass/page-404.php
DEBUG - 2014-12-27 10:28:26 --> File loaded: application/views/themes/prabhabrass.php
DEBUG - 2014-12-27 10:28:26 --> Final output sent to browser
DEBUG - 2014-12-27 10:28:26 --> Total execution time: 0.0980
DEBUG - 2014-12-27 10:28:29 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:29 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:29 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:29 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:29 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:29 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:29 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:29 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:29 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:29 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:31 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:31 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:31 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:31 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:31 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:31 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:31 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:31 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:31 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:31 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:31 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:32 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:32 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:32 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:32 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:32 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:32 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:32 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:32 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:32 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:32 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:32 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:32 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:32 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:32 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:32 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:32 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:32 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:32 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:32 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:32 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:32 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:32 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:32 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:32 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:32 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:32 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:32 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:32 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:28:32 --> Config Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:28:32 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:28:32 --> URI Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Router Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Output Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Security Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Input Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:28:32 --> Language Class Initialized
DEBUG - 2014-12-27 10:28:32 --> Loader Class Initialized
DEBUG - 2014-12-27 10:28:33 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:28:33 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:28:33 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:28:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:28:33 --> Session Class Initialized
DEBUG - 2014-12-27 10:28:33 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:28:33 --> Session routines successfully run
DEBUG - 2014-12-27 10:28:33 --> Controller Class Initialized
DEBUG - 2014-12-27 10:28:33 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:33 --> Model Class Initialized
DEBUG - 2014-12-27 10:28:33 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:28:33 --> DB Transaction Failure
ERROR - 2014-12-27 10:28:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:28:33 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:29:28 --> Config Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:29:28 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:29:28 --> URI Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Router Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Output Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Security Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Input Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:29:28 --> Language Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Loader Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:29:28 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:29:28 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:29:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:29:28 --> Session Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:29:28 --> Session routines successfully run
DEBUG - 2014-12-27 10:29:28 --> Controller Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Model Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Model Class Initialized
DEBUG - 2014-12-27 10:29:28 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:29:28 --> DB Transaction Failure
ERROR - 2014-12-27 10:29:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:29:28 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:29:29 --> Config Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:29:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:29:29 --> URI Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Router Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Output Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Security Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Input Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:29:29 --> Language Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Loader Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:29:29 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:29:29 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:29:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:29:29 --> Session Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:29:29 --> Session routines successfully run
DEBUG - 2014-12-27 10:29:29 --> Controller Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Model Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Model Class Initialized
DEBUG - 2014-12-27 10:29:29 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:29:29 --> DB Transaction Failure
ERROR - 2014-12-27 10:29:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:29:29 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:29:40 --> Config Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:29:40 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:29:40 --> URI Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Router Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Output Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Security Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Input Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:29:40 --> Language Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Loader Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:29:40 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:29:40 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:29:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:29:40 --> Session Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:29:40 --> Session routines successfully run
DEBUG - 2014-12-27 10:29:40 --> Controller Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Model Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Model Class Initialized
DEBUG - 2014-12-27 10:29:40 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:29:40 --> DB Transaction Failure
ERROR - 2014-12-27 10:29:40 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:29:40 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:29:41 --> Config Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:29:41 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:29:41 --> URI Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Router Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Output Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Security Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Input Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:29:41 --> Language Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Loader Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:29:41 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:29:41 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:29:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:29:41 --> Session Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:29:41 --> Session routines successfully run
DEBUG - 2014-12-27 10:29:41 --> Controller Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Model Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Model Class Initialized
DEBUG - 2014-12-27 10:29:41 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:29:41 --> DB Transaction Failure
ERROR - 2014-12-27 10:29:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:29:41 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:30:19 --> Config Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:30:19 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:30:19 --> URI Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Router Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Output Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Security Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Input Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:30:19 --> Language Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Loader Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:30:19 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:30:19 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:30:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:30:19 --> Session Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:30:19 --> Session routines successfully run
DEBUG - 2014-12-27 10:30:19 --> Controller Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Model Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Model Class Initialized
DEBUG - 2014-12-27 10:30:19 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:30:19 --> DB Transaction Failure
ERROR - 2014-12-27 10:30:19 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:30:19 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:30:20 --> Config Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:30:20 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:30:20 --> URI Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Router Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Output Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Security Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Input Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:30:20 --> Language Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Loader Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:30:20 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:30:20 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:30:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:30:20 --> Session Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:30:20 --> Session routines successfully run
DEBUG - 2014-12-27 10:30:20 --> Controller Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Model Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Model Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:30:20 --> DB Transaction Failure
ERROR - 2014-12-27 10:30:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:30:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:30:20 --> Config Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:30:20 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:30:20 --> URI Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Router Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Output Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Security Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Input Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:30:20 --> Language Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Loader Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:30:20 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:30:20 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:30:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:30:20 --> Session Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:30:20 --> Session routines successfully run
DEBUG - 2014-12-27 10:30:20 --> Controller Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Model Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Model Class Initialized
DEBUG - 2014-12-27 10:30:20 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:30:20 --> DB Transaction Failure
ERROR - 2014-12-27 10:30:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:30:20 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:07 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:07 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:31:07 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Input Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:07 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:07 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:07 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:31:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:07 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:07 --> Session garbage collection performed.
DEBUG - 2014-12-27 10:31:07 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:07 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:07 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:07 --> DB Transaction Failure
ERROR - 2014-12-27 10:31:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:07 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:08 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:31:08 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Input Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:08 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:08 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:31:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:08 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:08 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:08 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:08 --> DB Transaction Failure
ERROR - 2014-12-27 10:31:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:08 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:31:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:08 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Input Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:08 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:08 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:31:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:08 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:08 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:08 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:31:08 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:08 --> DB Transaction Failure
ERROR - 2014-12-27 10:31:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:08 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Input Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:08 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:08 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:31:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:08 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:08 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:08 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:08 --> DB Transaction Failure
ERROR - 2014-12-27 10:31:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:08 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:08 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:08 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:31:08 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Input Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:08 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:08 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:09 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Database Driver Class Initialized
DEBUG - 2014-12-27 10:31:09 --> UTF-8 Support Enabled
ERROR - 2014-12-27 10:31:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:09 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:09 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:09 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:09 --> DB Transaction Failure
DEBUG - 2014-12-27 10:31:09 --> Input Class Initialized
ERROR - 2014-12-27 10:31:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:09 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:09 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:31:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:09 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:09 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:09 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:31:09 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Input Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:09 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:09 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:09 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:09 --> DB Transaction Failure
ERROR - 2014-12-27 10:31:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:09 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:31:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:09 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:09 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:09 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:09 --> DB Transaction Failure
ERROR - 2014-12-27 10:31:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:09 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:09 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:31:09 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Input Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:09 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:09 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:31:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:09 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:09 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:09 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:09 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:09 --> DB Transaction Failure
ERROR - 2014-12-27 10:31:09 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:09 --> Language file loaded: language/english/db_lang.php
DEBUG - 2014-12-27 10:31:11 --> Config Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Hooks Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Utf8 Class Initialized
DEBUG - 2014-12-27 10:31:11 --> UTF-8 Support Enabled
DEBUG - 2014-12-27 10:31:11 --> URI Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Router Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Output Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Security Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Input Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Global POST and COOKIE data sanitized
DEBUG - 2014-12-27 10:31:11 --> Language Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Loader Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Helper loaded: url_helper
DEBUG - 2014-12-27 10:31:11 --> Helper loaded: custom_helper
DEBUG - 2014-12-27 10:31:11 --> Database Driver Class Initialized
ERROR - 2014-12-27 10:31:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\xampp\htdocs\prabhabrass.com\system\database\drivers\mysql\mysql_driver.php 91
DEBUG - 2014-12-27 10:31:11 --> Session Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Helper loaded: string_helper
DEBUG - 2014-12-27 10:31:11 --> Session garbage collection performed.
DEBUG - 2014-12-27 10:31:11 --> Session routines successfully run
DEBUG - 2014-12-27 10:31:11 --> Controller Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Model Class Initialized
DEBUG - 2014-12-27 10:31:11 --> Pagination Class Initialized
DEBUG - 2014-12-27 10:31:11 --> DB Transaction Failure
ERROR - 2014-12-27 10:31:11 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND publish = 1
		ORDER BY name' at line 4
DEBUG - 2014-12-27 10:31:11 --> Language file loaded: language/english/db_lang.php
